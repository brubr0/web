<?php
	$host = '172.16.11.22';
	$dbname = 'kemb1_15_todo2';
	$user = 'kemb1_kemb1_15';
	$pass = 'letmeinplease123';

	try {
		$DBH = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	}
	catch(PDOException $e) {
		echo $e->getMessage();
	}
?>
